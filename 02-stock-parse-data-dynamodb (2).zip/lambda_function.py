# encoding: utf-8
'''
* 抓股票資料 2/3
* 收到S3更新的event, 解析爬回來的檔案,存入DynamoDB
* DynamoDB 先建好以下Table:
    Table       : stock
    Primary Key : id(string)
'''
from __future__ import print_function
import re
import time
import datetime
import logging
import boto3


# logging module
LOGGER = logging.getLogger()
LOGGER.setLevel(logging.INFO)  # 只輸出INFO & 以上等級的log

#  GLOBAL CONSTANT
OBJ_S3 = boto3.resource('s3')
OBJ_DDB = boto3.resource('dynamodb', region_name='us-east-1')
OBJ_TBL = OBJ_DDB.Table('stock')
stockid='';

def lambda_handler(event, context):
    '''
    entry point (lambda)
    '''

    # 從 s3產生出來的event 取出我們要的原始網頁
    s_content = get_object_content(event)

    # 解析網頁內容
    lst_data = parse_content(s_content)

    # 逐筆存到DynamoDB
    for item in lst_data:
        OBJ_TBL.put_item(
            Item={
                'stockid': item[0],
                'date': item[1],
                'amount': item[2]
            }
        )

    return None


def parse_content(s_content):
    '''
        解析網頁內容,預期最後處理成這樣的格式:
        ['109/01/02', 6,939,981, '166,483,631', '24.00', '24.10'],[.....
    '''
    # 重新切行
    s_content = s_content.replace('\n', '')
    #取出股票代號
    stockid = (s_content.split('</th>')[0]).split('月')[1].split(' ')[1] 
    LOGGER.info('stockid='+stockid)
    s_content = s_content.split('<tbody>')[1]
    lst_content = s_content.split('</tr>')

    lst_final = []
    for s_line in lst_content:

        # 第一次過濾: 每行有 <tr> 這樣的字串
        s_pattern = r'<tr>(.*)'
        s_match = re.search(s_pattern, s_line)
        if s_match is None:
            continue
        else:
            s_line = s_match.group(0)
            #LOGGER.info('s_line:'+s_line)

        # 二次過濾:檢查td欄位數
        lst_line = s_line.split('<td>')
        cols = 10
        if len(lst_line) == cols:
            # ok
            #print(len(lst_line))
            pass
        else:
            # fail, html table format changed?
            LOGGER.warning('欄位數有誤,請檢查是否Table格式改變')
            LOGGER.warning(s_line)
            #print(len(lst_line))
            continue

        # 至此,每一行應該都是合格的資料,等待切欄位parse

        # 1.日期
        #s_pattern = r'>(.*)<'
        s_match =lst_line[1].split('</td>')[0]
        LOGGER.info('日期:'+s_match)
        if s_match is None:
            continue
        else:
            s_date =s_match
            #LOGGER.info('日期:'+s_date)
        # 2.成交量
        #s_pattern = r'>(.*)</'
        s_match =lst_line[2].split('</td>')[0]
        if s_match is None:
            continue
        else:
            s_stock = s_match
            LOGGER.info('成交股數'+s_stock)

        lst_row = [stockid,s_date,s_stock]

        lst_final.append(lst_row)

    LOGGER.info('total records:' + str(len(lst_final)))
    return lst_final


def get_object_content(event):
    '''
    從 s3產生出來的event 取出我們需要處理的那個檔案
    '''
    # 從event 取得檔名/bucket等資訊
    dict_event = event['Records'][0]
    s_object_name = dict_event['s3']['object']['key']
    s_bucket = dict_event['s3']['bucket']['name']

    # download file & convert to string
    s_content = s3_download_to_string(s_bucket, s_object_name)

    return s_content


def s3_download_to_string(s_bucket, s_object_name):
    '''
    下載 S3 object ,然後不寫檔, 直接轉成字串
    '''

    obj = OBJ_S3.Object(s_bucket, s_object_name)
    s_out = obj.get()['Body'].read().decode('utf-8')

    return s_out


if __name__ == '__main__':
    '''
    entry point
    '''
    lambda_handler(None, None)